package com.way2learnonline.domain;

public enum ShipmentType {

	CAR, PLANE, SHIP, TRAIN;
	
}
