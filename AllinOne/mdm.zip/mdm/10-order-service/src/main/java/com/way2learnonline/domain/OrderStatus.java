package com.way2learnonline.domain;

public enum OrderStatus {

	NEW, PROCESSING, DONE, ERROR;
	
}
