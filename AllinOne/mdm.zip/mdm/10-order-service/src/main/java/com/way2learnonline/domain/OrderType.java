package com.way2learnonline.domain;

public enum OrderType {

	PURCHASE, RETURN, EXCHANGE;
}
